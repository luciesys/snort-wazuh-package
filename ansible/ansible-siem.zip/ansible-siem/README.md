# 🤖 ANSIBLE - Déploiement SIEM Automatisé

## 📋 C'est quoi ce dossier ?

Ce dossier contient tout ce qu'il faut pour **installer automatiquement** le SIEM (Snort + Wazuh) sur **plusieurs serveurs en même temps**.

---

## 🎯 Pourquoi utiliser Ansible ?

| Sans Ansible | Avec Ansible |
|--------------|--------------|
| Tu te connectes à chaque serveur | Tu lances **1 commande** |
| Tu tapes les mêmes commandes X fois | Ansible fait tout **automatiquement** |
| Si tu as 10 serveurs = 10 installations manuelles | 10 serveurs = **1 seule commande** |
| Risque d'erreur humaine | **Toujours la même installation** |

---

## 📁 Structure des fichiers

```
ansible-siem/
│
├── install_ansible.sh      ← Script pour installer Ansible
├── inventory.ini           ← Liste de tes serveurs (À MODIFIER)
├── ansible.cfg             ← Configuration (ne pas toucher)
│
└── playbooks/
    ├── install_siem.yml    ← Installe Snort + Wazuh
    ├── install_agent.yml   ← Installe l'agent sur les clients
    └── uninstall_siem.yml  ← Désinstalle tout
```

---

## 🚀 Comment utiliser ?

### Étape 1 : Installer Ansible (sur ton PC, pas sur les serveurs)

```bash
curl -sL https://raw.githubusercontent.com/.../install_ansible.sh | bash
```

### Étape 2 : Configurer les serveurs cibles

Édite le fichier `inventory.ini` :

```bash
nano inventory.ini
```

Ajoute tes serveurs :

```ini
[siem_servers]
192.168.1.100 ansible_user=admin ansible_password=MonPassword
```

### Étape 3 : Lancer l'installation

```bash
ansible-playbook playbooks/install_siem.yml
```

**C'est tout !** Ansible va installer sur tous tes serveurs automatiquement.

---

## 📖 Les playbooks expliqués

### 🛡️ install_siem.yml

**Ce qu'il fait :**
1. Vérifie que le serveur est compatible (Ubuntu/Debian, RAM, disque)
2. Nettoie les anciennes installations
3. Met à jour le système
4. Installe Snort (détection d'intrusions)
5. Installe Wazuh (SIEM complet avec dashboard)
6. Configure l'intégration Snort-Wazuh
7. Affiche les infos de connexion

**Comment l'utiliser :**
```bash
ansible-playbook playbooks/install_siem.yml
```

---

### 📦 install_agent.yml

**Ce qu'il fait :**
1. Installe l'agent Wazuh sur les machines clientes
2. Configure l'agent pour se connecter au serveur SIEM
3. Démarre l'agent

**Comment l'utiliser :**
```bash
ansible-playbook playbooks/install_agent.yml
```

---

### 🗑️ uninstall_siem.yml

**Ce qu'il fait :**
1. Arrête tous les services
2. Désinstalle Snort et Wazuh
3. Supprime tous les fichiers et logs

**Comment l'utiliser :**
```bash
ansible-playbook playbooks/uninstall_siem.yml
```

⚠️ **ATTENTION** : Cette action est irréversible !

---

## ❓ FAQ

### Comment ajouter un nouveau serveur ?

Édite `inventory.ini` et ajoute une ligne :
```ini
[siem_servers]
192.168.1.100 ansible_user=admin ansible_password=pass1
192.168.1.101 ansible_user=admin ansible_password=pass2  ← Nouvelle ligne
```

### Comment installer sur un seul serveur ?

```bash
ansible-playbook playbooks/install_siem.yml --limit 192.168.1.100
```

### Comment voir ce qui va se passer sans exécuter ?

```bash
ansible-playbook playbooks/install_siem.yml --check
```

### Comment avoir plus de détails pendant l'exécution ?

```bash
ansible-playbook playbooks/install_siem.yml -v      # Verbeux
ansible-playbook playbooks/install_siem.yml -vvv    # Très verbeux
```

---

## 📞 Support

En cas de problème, vérifie :
1. Que tu peux te connecter en SSH aux serveurs
2. Que les serveurs ont accès à Internet
3. Que les credentials dans `inventory.ini` sont corrects

Teste la connexion avec :
```bash
ansible all -m ping
```
